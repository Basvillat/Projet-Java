/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author 931701772
 */
public class Eleve extends Utilisateur{
    private int numero;
    private int idGroupe;
    
    public Eleve(int id,int numero,int id_groupe){
            super();
    this.numero=numero;
    idGroupe=id_groupe;
    }
    
    public Eleve(){
            super();
    
    }
}
