/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author 931701772
 */
public class Salle {
  //ID
  private int id = 0;
  //Nom du professeur
  private String nom = "";
  private String capacite = "";
  private String id_Site = "";

  public Salle(int id, String nom,String capacite,String id_Site) {
    this.id = id;
    this.nom = nom;
    this.capacite=capacite;
    this.id_Site=id_Site;
    
  }

  public Salle(){}

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getNom() {
    return nom;
  }

  public void setNom(String nom) {
    this.nom = nom;
  }   
}