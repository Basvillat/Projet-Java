/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;
import java.util.Set;
import java.util.HashSet;

/**
 *
 * @author 931701772
 */
public class Ecole {
  //ID
  private int id = 0;
  //Nom du professeur
  private String nom = "";
  //Liste des professeurs
  private Set<Utilisateur> listUtilisateur = new HashSet<Utilisateur>();
  //Liste des élèves
  private Set<Eleve> listEleve = new HashSet<Eleve>();
private Set<Professeur> listProfesseur = new HashSet<Professeur>();
          
  public Ecole(int id, String nom) {
    this.id = id;
    this.nom = nom;
  }
  public Ecole(){}

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getNom() {
    return nom;
  }

  public void setNom(String nom) {
    this.nom = nom;
  }

  public Set<Utilisateur> getListUtilisateur() {
    return listUtilisateur;
  }

  public void setListUtilisateur(Set<Utilisateur> listUtilisateur) {
    this.listUtilisateur = listUtilisateur;
  }

  public void addUtilisateur(Utilisateur util) {
    if(!listUtilisateur.contains(util))
      listUtilisateur.add(util);
  }

  public void removeUtilisateur(Utilisateur util ) {
    this.listUtilisateur.remove(util);
  }

  public Set<Eleve> getListEleve() {
    return listEleve;
  }

  public void setListEleve(Set<Eleve> listEleve) {
    this.listEleve = listEleve;
  }

  //Ajoute un élève à la classe
  public void addEleve(Eleve eleve){
    if(!this.listEleve.contains(eleve))
      this.listEleve.add(eleve);
  }

  //Retire un élève de la classe
  public void removeEleve(Eleve eleve){
    this.listEleve.remove(eleve);
  }
  
  public Set<Professeur> getListProfesseur() {
    return listProfesseur;
  }

  public void setListProfesseur(Set<Professeur> listProfesseur) {
    this.listProfesseur = listProfesseur;
  }

  public void addProfesseur(Professeur prof) {
    if(!listProfesseur.contains(prof))
      listProfesseur.add(prof);
  }

  public void removeProfesseur(Professeur prof ) {
    this.listProfesseur.remove(prof);
  }

  public boolean equals(Ecole cls){
    return this.getId() == cls.getId();
  }   
}
