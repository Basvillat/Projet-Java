/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;
import java.util.Date;

/**
 *
 * @author 931701772
 */
public class Seance {
    //ID
  private int id = 0;
  //Nom du professeur
  private int semaine ;
  private Date maDate;
  private String heureDebut;
  private String heureFin;
  private String etat = "";
  private int id_Cours = 0;
  private int id_Type = 0;

  public Seance(int id, int semaine,Date maDate,String heureDebut,String heureFin,String etat, int id_Cours,int id_Type) {
    this.id = id;
    this.semaine = semaine;
    this.maDate=maDate;
    this.heureDebut=heureDebut;
    this.heureFin=heureFin;
    this.etat=etat;
    this.id_Cours=id_Cours;
    this.id_Type=id_Type;
    
  }
  
    public Seance() {
   
    
  }


  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getSemaine() {
    return semaine;
  }

  public void setSemaine(int semaine) {
    this.semaine = semaine;
  }   
}
