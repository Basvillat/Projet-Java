package vue;
import modele.Utilisateur;
import modele.Eleve;
import modele.Ecole;
import modele.Professeur;
import java.sql.Connection;
import java.sql.*;
import controleur.DAO;
import controleur.UtilisateurDAO;
import controleur.UtilisateurDAO;



import modele.Utilisateur;
//CTRL + SHIFT + O pour générer les imports
public class Test { 
  public static void main(String[] args) {
      
      //Testons des élèves
    DAO<Utilisateur> utilisateurDao = new UtilisateurDAO(SdzConnection.getInstance());
    for(int i = 1; i < 5; i++){
      Utilisateur monUtilisateur = utilisateurDao.find(i);
      System.out.println("Elève N°" + monUtilisateur.getId() + "  - " + monUtilisateur.getNom() + " " + monUtilisateur.getPrenom());
    }
      
    System.out.println("\n********************************\n");
    
    //Testons des élèves
    DAO<Eleve> eleveDao = new EleveDAO(SdzConnection.getInstance());
    for(int i = 1; i < 5; i++){
      Eleve eleve = eleveDao.find(i);
      System.out.println("Elève N°" + eleve.getId() + "  - " + eleve.getNom() + " " + eleve.getPrenom());
    }
      
    System.out.println("\n********************************\n");
      
    //Voyons voir les professeurs
    DAO<Professeur> profDao = new ProfesseurDAO(SdzConnection.getInstance());
    for(int i = 4; i < 8; i++){
      Professeur prof = profDao.find(i);
      System.out.println(prof.getNom() + " " + prof.getPrenom() + " enseigne : ");
      //for(Matiere mat : prof.getListMatiere())
       // System.out.println("\t * " + mat.getNom());
    }
      
    System.out.println("\n********************************\n");
      
    //Et là, c'est la classe
    DAO<Ecole> classeDao = new EcoleDAO(SdzConnection.getInstance());
    Ecole ecole = classeDao.find(11);
      
    System.out.println("Classe de " + ecole.getNom());
    System.out.println("\nListe des élèves :");
    ecole.getListEleve().forEach((eleve) -> {
        System.out.println("  - " + eleve.getNom() + " " + eleve.getPrenom());
      });
      
    System.out.println("\nListe des professeurs :");
    ecole.getListProfesseur().forEach((prof) -> {
        System.out.println("  - " + prof.getNom() + " " + prof.getPrenom());      
      });
  }
}