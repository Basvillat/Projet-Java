/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controleur;


import java.sql.ResultSet;
import java.sql.SQLException;
import modele.Seance;
import java.sql.Connection;
import java.util.Date;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 931701772
 */

public class SeanceDAO extends DAO<Seance> {
  public SeanceDAO(Connection conn) {
    super(conn);
  }

  @Override
  public boolean create(Seance obj) {
    return false;
  }

  @Override
  public boolean delete(Seance obj) {
    return false;
  }
   
  @Override
  public boolean update(Seance obj) {
    return false;
  }
   
  @Override
  public Seance find(int id) {
    Seance maSeance = new Seance();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM salle WHERE id = " + id);
      if(result.first())
        maSeance = new Seance(
          id,
          result.getInt("semaine"),
          result.getDate("date"),
          result.getString("heure_debut"),
          result.getString("heure_fin"),
          result.getString("etat"),
          result.getInt("id_Cours"),
          result.getInt("id_Type")
        );         
      
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return maSeance;
  }
}