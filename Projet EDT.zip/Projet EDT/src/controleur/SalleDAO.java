/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controleur;
import modele.Salle;
import java.sql.Connection;
import java.sql.*;
/**
 *
 * @author 931701772
 */

public class SalleDAO extends DAO<Salle> {
  public SalleDAO(Connection conn) {
    super(conn);
  }

  @Override
  public boolean create(Salle obj) {
    return false;
  }

  @Override
  public boolean delete(Salle obj) {
    return false;
  }
   
  @Override
  public boolean update(Salle obj) {
    return false;
  }
   
  @Override
  public Salle find(int id) {
    Salle maSalle = new Salle();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM salle WHERE id = " + id);
      if(result.first())
        maSalle = new Salle(
          id,
          result.getString("nom"),
          result.getString("capacite"),
          result.getString("id_site")
        );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return maSalle;
  }
}