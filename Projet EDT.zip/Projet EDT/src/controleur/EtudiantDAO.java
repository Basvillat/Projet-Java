/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controleur;

import modele.Eleve;
import java.sql.Connection;
import java.sql.*;

/**
 *
 * @author 931701772
 */

public class EtudiantDAO extends DAO<Eleve> {
  public EtudiantDAO(Connection conn) {
    super(conn);
  }

  @Override
  public boolean create(Eleve obj) {
    return false;
  }

  @Override
  public boolean delete(Eleve obj) {
    return false;
  }
   
  @Override
  public boolean update(Eleve obj) {
    return false;
  }
   
  @Override
  public Eleve find(int id) {
    Eleve eleve = new Eleve();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM eleve WHERE elv_id = " + id);
      if(result.first())
        eleve = new Eleve(
          id,
          result.getInt("numero"),
          result.getInt("id_groupe"
        ));         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return eleve;
  }
}